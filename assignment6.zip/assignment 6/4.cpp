#include <iostream>
using namespace std;
void WhatIsFuction();

void inputArray(char **arr, int &row, int &col, char **arr2);
void outputArray(char **arr, int row, int col, char **arr2);
void asciiCode(char **arr, int row, int col, char **arr2);

int main()
{
    WhatIsFuction();
    int row = 0;
    int col = 0;

    char **arr = new char *[row];
    char **arr2 = new char *[row];
    for (int i = 0; i < row; i++)
    {
        arr[i] = new char[col];
    }
    for (int i = 0; i < row; i++)
    {
        arr2[i] = new char[col];
    }
    inputArray(arr, row, col, arr2);
    outputArray(arr, row, col, arr2);
    asciiCode(arr, row, col, arr2);

    return 0;
}
void inputArray(char **arr, int &row, int &col, char **arr2)
{
    cout << "\n--------------------------------------ENTER A ROWS--------------------------------------------\n";
    cout << "ROWS:";
    cin >> row;
    cout << "\n--------------------------------------ENTER A COLUMN--------------------------------------------\n";
    cout << "COLUMN:";
    cin >> col;

    for (int i = 0; i < row; i++)
    {

        for (int j = 0; j < col; j++)
        {
            cout << "[" << i << "][" << j << "] ";
            cin >> arr[i][j];
        }
    }
}
void outputArray(char **arr, int row, int col, char **arr2)
{
    cout << "\n--------------------------------------ENTER VALUES--------------------------------------------\n";
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << "[" << i << "][" << j << "] ";
            cout << arr[i][j] << "  ";
        }
        cout << endl;
    }
}
void asciiCode(char **arr, int row, int col, char **arr2)
{
    cout << "\n--------------------------------------SOLUTION--------------------------------------------\n";
    cout << endl;
    cout << endl;
    cout << endl;
    int sum = 0;
    int max = 0;
    int m = 0;
    int n = 0;

    int index = 0;
    for (int i = 0; i < row; i++)
    {
        int j = 0;
        for (; j < col; j++)
        {

            sum += int(arr[i][j]);
            index = i;
        }

        if (max < sum)
        {
            max = sum;
            for (int o = 0; o < 1; o++)
            {
                for (int p = 0; p < col; p++)
                {
                    arr2[m][n++] = arr[index][p];
                }
            }
            n = 0;
            m = 0;
        }

        sum = 0;
    }
    cout << "Maximum Ascii is this : " << max;
    cout << endl;
    cout << "Value Of Maximum Asci";
    cout << endl;
    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << arr2[i][j] << " ";
        }
    }
}

void WhatIsFuction()
{
    cout << "\t\t\t\t MAXIMUM ASCII CODE \n";
}