#include <iostream>
using namespace std;
void WhatIsFuction();
void inputArray(int **arr, int &row, int &col);
void outputArray(int **arr, int row, int col);
void swapDiagnol(int **arr, int row, int col);
int main()
{
    WhatIsFuction();
    int row = 0;
    int col = 0;

    int **arr = new int *[row];

    inputArray(arr, row, col);
    outputArray(arr, row, col);
    swapDiagnol(arr, row, col);

    return 0;
}
void inputArray(int **arr, int &row, int &col)
{
    cout << "\n--------------------------------------ENTER A ROWS--------------------------------------------\n";
    cout << "ROWS:";
    cin >> row;
    cout << "\n--------------------------------------ENTER A COLUMN--------------------------------------------\n";
    cout << "COLUMN:";
    cin >> col;
    for (int i = 0; i < row; i++)
    {
        arr[i] = new int[col];
    }
    cout << "ENTER A VALUES ";
    cout << endl;
    for (int i = 0; i < row; i++)
    {

        for (int j = 0; j < col; j++)
        {
            cout << "[" << i << "][" << j << "] ";
            cin >> arr[i][j];
        }
    }
}
void outputArray(int **arr, int row, int col)
{
    if (row == 0)
    {
        cout << " DATA IS NOT PRESENT ";
    }
    else
    {
        for (int i = 0; i < row; i++)
        {

            for (int j = 0; j < col; j++)
            {
                cout << "[" << i << "][" << j << "] ";
                cout << arr[i][j] << "  ";
            }
            cout << endl;
          
        }
    }
}
void swapDiagnol(int **arr, int row, int col)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            if (i == j)
            {
                int temp = 0;
                temp = arr[i][j];
                arr[i][j] = arr[i][row - i - 1];
                arr[i][row - i - 1] = temp;
            }
        }
    }
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    outputArray(arr, row, col);
}
void WhatIsFuction()
{
    cout << "\t\t\t\t DIAGNOL SWAP \n";
}