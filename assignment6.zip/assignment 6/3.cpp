#include <iostream>
using namespace std;
void WhatIsFuction();
void inputArray(int **arr, int &row, int &col);
void outputArray(int **arr, int row, int col);
int mirrorMatrix(int **arr1, int row1, int col1, int **arr2, int row2, int col2);
int main()
{
    WhatIsFuction();
    int row1 = 0;
    int col1 = 0;
    int row2 = 0;
    int col2 = 0;
    int returnValue = 0;
    int **arr1 = new int *[row1];
    int **arr2 = new int *[row2];
    cout << "\n--------------------------------------FIRST MATRIX--------------------------------------------\n";
    inputArray(arr1, row1, col1);
    outputArray(arr1, row1, col1);
    cout << "\n--------------------------------------SECOND MATRIX--------------------------------------------\n";
    inputArray(arr2, row2, col2);
    outputArray(arr2, row2, col2);
    returnValue = mirrorMatrix(arr1, row1, col1, arr2, row2, col2);
    if (returnValue == -1)
    {
        cout << "THIS IS NOT MIRROR MATRIX ";
    }
    if (returnValue == 1)
    {
        cout << "THIS IS  MIRROR MATRIX ";
    }

    return 0;
}
void inputArray(int **arr, int &row, int &col)
{
    cout << "\n--------------------------------------ENTER A ROWS--------------------------------------------\n";
    cout << "ROWS:";
    cin >> row;
    cout << "\n--------------------------------------ENTER A COLUMN--------------------------------------------\n";
    cout << "COLUMN:";
    cin >> col;

    for (int i = 0; i < row; i++)
    {
        arr[i] = new int[col];
    }

    cout << "ENTER A VALUES INTO MATRIX ";
    cout << endl;
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << "[" << i << "][" << j << "] ";
            cin >> arr[i][j];
        }
    }
}
void outputArray(int **arr, int row, int col)
{
    if (row == 0)
    {
        cout << endl;
        cout << "DATA IS EMPTY ";
        cout << endl;
    }
    else
    {
        cout << endl;
        cout << " VALUES INTO MATRIX ";
        cout << endl;
        for (int i = 0; i < row; i++)
        {

            for (int j = 0; j < col; j++)
            {
                cout << "[" << i << "][" << j << "] ";
                cout << arr[i][j] << "  ";
            }
            cout << endl;
            // cout << "-------------------------------------------------------------------------------------------";
            // cout << endl;
        }
    }
}
int mirrorMatrix(int **arr1, int row1, int col1, int **arr2, int row2, int col2)
{
    bool found = 0;
    if (row1 != row2)
    {
        return -1;
    }
    else
    {

        for (int i = 0; i < row1; i++)
        {
            for (int j = 0; j < col1; j++)
            {
                if (arr1[i][j] != arr2[i][row1 - j - 1])
                {
                    return -1;
                    found == 1;

                    break;
                }
            }
        }
    }
    return 1;
}

void WhatIsFuction()
{
    cout << "\t\t\t\t MIRROR MATRIX \n";
}