#include <iostream>
using namespace std;
void WhatIsFuction();
void inputArray(float *arr, int row, int col);
void outputArray(float *arr, int row, int col);
void calculateCgpa(float *arr, int row, int col);
int main()
{
    WhatIsFuction();
    int row = 3;
    int col = 2;
    float arr[row][col] = {0}; // intalize the 2D array with zero
    inputArray((float *)arr, row, col);
    outputArray((float *)arr, row, col);
    calculateCgpa((float *)arr, row, col);
    return 0;
}
void inputArray(float *arr, int row, int col)
{
    cout << "ENTER A GPA FOR CALCULATE ";
    cout << endl;
    for (int i = 0; i < row; i++)
    {

        for (int j = 0; j < col; j++)
        {
            cout << "[" << i << "][" << j << "] ";
            cin >> *(arr + i * col + j);
        }
    }
}
void outputArray(float *arr, int row, int col)
{
    for (int i = 0; i < row; i++)
    {
        cout << "GPA OF " << i + 1 << " STUDENT \n";
        for (int j = 0; j < col; j++)
        {
            cout << "[" << i << "][" << j << "] ";
            cout << *(arr + i * col + j) << "  ";
        }
        cout << endl;
        cout << "-------------------------------------------------------------------------------------------";
        cout << endl;
    }
}
void calculateCgpa(float *arr, int row, int col)
{
    float calculateCgpa = 0;
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {

            calculateCgpa += *(arr + i * col + j);
        }
        cout << "CGPA OF STUDENT #" << i + 1 << " " << calculateCgpa / col << endl;
        calculateCgpa = 0;
    }
}
void WhatIsFuction()
{
    cout << "\t\t\t\t CGPA CALCULATER \n";
}